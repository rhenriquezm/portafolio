## Usage
    
    <context-param>
        <param-name>primefaces.THEME</param-name>
        <param-value>metroui</param-value>
    </context-param>
